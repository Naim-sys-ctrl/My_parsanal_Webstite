/* Portfolio scripts: theme, menu, typing text, skill bars, network background, contact form */
(function () {
  "use strict";

  var root = document.documentElement;
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- 1. Dark / light mode ---------- */
  var saved = null;
  try { saved = localStorage.getItem("theme"); } catch (e) {}
  var prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  root.setAttribute("data-theme", saved || (prefersDark ? "dark" : "light"));

  document.getElementById("theme-toggle").addEventListener("click", function () {
    var next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
    root.setAttribute("data-theme", next);
    try { localStorage.setItem("theme", next); } catch (e) {}
  });

  /* ---------- 2. Mobile menu ---------- */
  var menuBtn = document.getElementById("menu-btn");
  var navLinks = document.getElementById("nav-links");
  menuBtn.addEventListener("click", function () {
    var open = navLinks.classList.toggle("open");
    menuBtn.setAttribute("aria-expanded", open);
  });
  navLinks.querySelectorAll("a").forEach(function (link) {
    link.addEventListener("click", function () {
      navLinks.classList.remove("open");
      menuBtn.setAttribute("aria-expanded", "false");
    });
  });

  /* ---------- 3. Highlight current section in the menu ---------- */
  var sections = document.querySelectorAll("main section[id]");
  var linkMap = {};
  navLinks.querySelectorAll("a").forEach(function (a) { linkMap[a.getAttribute("href").slice(1)] = a; });
  if ("IntersectionObserver" in window) {
    var navObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          Object.keys(linkMap).forEach(function (id) { linkMap[id].classList.remove("active"); });
          if (linkMap[entry.target.id]) linkMap[entry.target.id].classList.add("active");
        }
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    sections.forEach(function (s) { navObserver.observe(s); });
  }

  /* ---------- 4. Typing text in the hero ---------- */
  var words = ["networks.", "computers.", "Python code.", "websites."];
  var typedEl = document.getElementById("typed");
  var w = 0, c = 0, deleting = false;
  function type() {
    var word = words[w];
    typedEl.textContent = word.slice(0, c);
    if (!deleting && c === word.length) { deleting = true; return setTimeout(type, 1400); }
    if (deleting && c === 0) { deleting = false; w = (w + 1) % words.length; return setTimeout(type, 300); }
    c += deleting ? -1 : 1;
    setTimeout(type, deleting ? 45 : 90);
  }
  if (reduceMotion) { typedEl.textContent = words[0]; } else { type(); }

  /* ---------- 5. Skill bars fill when visible ---------- */
  var bars = document.querySelectorAll(".bar span");
  function fill(bar) { bar.style.width = bar.getAttribute("data-level") + "%"; }
  if ("IntersectionObserver" in window) {
    var barObserver = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { fill(entry.target); obs.unobserve(entry.target); }
      });
    }, { threshold: 0.4 });
    bars.forEach(function (b) { barObserver.observe(b); });
  } else {
    bars.forEach(fill);
  }

  /* ---------- 6. Network background (a nod to networking) ---------- */
  var canvas = document.getElementById("network-canvas");
  var ctx = canvas.getContext("2d");
  var nodes = [], width = 0, height = 0;

  function resize() {
    var ratio = window.devicePixelRatio || 1;
    width = canvas.offsetWidth; height = canvas.offsetHeight;
    canvas.width = width * ratio; canvas.height = height * ratio;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    var count = Math.min(60, Math.floor(width / 24));
    nodes = [];
    for (var i = 0; i < count; i++) {
      nodes.push({ x: Math.random() * width, y: Math.random() * height, vx: (Math.random() - .5) * .4, vy: (Math.random() - .5) * .4 });
    }
  }
  function draw() {
    var rgb = getComputedStyle(root).getPropertyValue("--node").trim();
    ctx.clearRect(0, 0, width, height);
    nodes.forEach(function (n) {
      if (!reduceMotion) {
        n.x += n.vx; n.y += n.vy;
        if (n.x < 0 || n.x > width) n.vx *= -1;
        if (n.y < 0 || n.y > height) n.vy *= -1;
      }
      ctx.beginPath(); ctx.arc(n.x, n.y, 2.2, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(" + rgb + ",.55)"; ctx.fill();
    });
    for (var i = 0; i < nodes.length; i++) {
      for (var j = i + 1; j < nodes.length; j++) {
        var dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y, d = Math.sqrt(dx * dx + dy * dy);
        if (d < 130) {
          ctx.strokeStyle = "rgba(" + rgb + "," + (0.25 * (1 - d / 130)) + ")";
          ctx.beginPath(); ctx.moveTo(nodes[i].x, nodes[i].y); ctx.lineTo(nodes[j].x, nodes[j].y); ctx.stroke();
        }
      }
    }
    if (!reduceMotion) requestAnimationFrame(draw);
  }
  resize(); draw();
  window.addEventListener("resize", function () { resize(); if (reduceMotion) draw(); });

  /* ---------- 7. Contact form (opens your email app) ---------- */
  var form = document.getElementById("contact-form");
  var status = document.getElementById("form-status");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var name = form.elements["name"], email = form.elements["email"], message = form.elements["message"], ok = true;
    [name, email, message].forEach(function (f) { f.classList.remove("invalid"); });
    if (!name.value.trim()) { name.classList.add("invalid"); ok = false; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) { email.classList.add("invalid"); ok = false; }
    if (!message.value.trim()) { message.classList.add("invalid"); ok = false; }
    if (!ok) {
      status.className = "form-status error";
      status.textContent = "Please fill in your name, a valid email and a message.";
      return;
    }
    var subject = encodeURIComponent("Portfolio message from " + name.value.trim());
    var body = encodeURIComponent(message.value.trim() + "\n\nFrom: " + name.value.trim() + " (" + email.value.trim() + ")");
    window.location.href = "mailto:naime205552@gmail.com?subject=" + subject + "&body=" + body;
    status.className = "form-status ok";
    status.textContent = "Your email app is opening. Press send there to finish.";
    form.reset();
  });

  /* ---------- 8. Footer year ---------- */
  document.getElementById("year").textContent = new Date().getFullYear();
})();
